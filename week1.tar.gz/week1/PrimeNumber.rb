require 'cmath'
puts "n : "
n = gets
n = n.to_i
def SNT(n)
	if n==2 
		return "N la so nguyen to"
	elsif n<2 
		return "N khong phai so nguyen to"
	else
		m = CMath.sqrt(n)
		(2..m).each{|m|
			if n%m==0 
				return "N khong phai so nguyen to"
			end 
		}		
		return "N la so nguyen to"
	end
end
puts SNT(n)