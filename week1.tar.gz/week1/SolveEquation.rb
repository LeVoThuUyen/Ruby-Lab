require 'cmath'
puts "Enter the equation"
puts "a: "
a = gets
a = a.to_i
puts "b: "
b = gets
b = b.to_i
puts "c: "
c = gets
c = c.to_i
d = (b*b)-(4*a*c)
if a == 0 then
	puts "Day khong phai la phuong trinh bac 2"
else
	if  d<0  then
		puts "Phuong trinh vo nghiem"
	elsif d == 0 then
	    puts "Phuong trinh co nghiem kep :  #{( - b)/(2*a)}"
	else 
		puts " Phuong trinh co hai nghiem phan biet la #{(Math.sqrt(d)-b)/(2*a)} va #{(-Math.sqrt(d)-b)/(2*a)}"
	end
end